const express = require("express");
const app=express();
// console.dir(app);
let port=8080;
app.listen(port, ()=>{
    console.log(`app is listening on port ${port}`);

});
// app.use((req, res)=>{
//     // console.log(req);
//     console.log("request recieved");
//     //sending object in response
//     // res.send({
//     //     name:"apple",
//     //     color:"red",
//     // });
//     //send response in html format
//     let code="<h1>AStha Shukla</h1> <ul><li>apple</li><li>mango</li></ul>"
// res.send(code);

//});
app.get("/",(req,res)=>{
    res.send("hello i'm root");
});
// app.get("/apple",(req,res)=>{
// res.send("you contacted apple path");
// });
// app.get("/mango",(req,res)=>{
//     res.send("you contacted mango path");
// });
// app.get("*",(req,res)=>{
//     res.send("this path not exist");
// })

// app.post("/",(req,res)=>{
//     res.send("you send a post request");
// });
app.get("/:username/:id",(req,res)=>{
    let{username, id}=req.params;
    let htmlStr=`<h1>Hello i,m asthaaaaaa of @${username}</h1>`
    res.send(htmlStr);
    // console.log(req.params);
    // res.send(`welcom to page @${username}.`);
});

app.get("/search",(req,res)=>{
    let {q}=req.query;
    if(!q){
        res.send("<h1>not searched</h1>");
    }
    // console.log(req.query);
    res.send(`<h1>search results:${q}</h1>`);
}
);