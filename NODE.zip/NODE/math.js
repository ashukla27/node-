export const sum=(a,b)=> a+b;
export const mul=(a,b)=> a*b;

// //or module.exports.sum=(a,b)=>a+b;

// //or
// //exports.sum=(a,b)=>a+b;
// const mul=(a,b)=> a*b;
export const g=9.8;
export const PI =3.14;
// // module.exports=123;

// let obj={
//     sum:sum,
//     mul:mul,
//     g:g,
//     PI:PI
// };
// module.exports=obj;