const express=require("express");
const app=express();//express internally require ejs
const path=require("path");
const port=8080;
app.use(express.static(path.join(__dirname, "public")));
app.set("view engine", "ejs");//set view engine to ejs
app.get("/",(req,res)=>{

app.set("views",path.join(__dirname,"/views"));//shows the path of the views folder
    res.render("home.ejs");
});

app.get("/hello",(req,res)=>{
    res.send("hello jii");
});

app.get("/rolldice",(req,res)=>{
    let diceVal=Math.floor(Math.random() * 6) + 1;
    res.render("rolldice.ejs",{diceVal});
});


//instagram

app.get("/ig/:username",(req,res)=>{
    let {username}=req.params;
    const instaData=require("./data.json");
    const data=instaData[username];
    if(data){
    res.render("instagram.ejs",{ data });
}else{
    res.render("error.ejs");
}
});
app.listen(port, ()=>{
    console.log(`listening on port ${port}`);
});