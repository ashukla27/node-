module.exports={
    name:"apple",
    color:"red",
};