module.exports={
    name:"orange",
    color:"orange",
};