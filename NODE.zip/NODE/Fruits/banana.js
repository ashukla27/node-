module.exports={
    name:"banana",
    color:"yellow",
};