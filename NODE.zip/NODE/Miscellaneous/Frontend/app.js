// let arr=[1,2,3];
// let arr2=[4,5,6];
// arr.sayHello=()=>{
//     console.log("hello i'm arr");
// };

// arr2.sayHello=()=>{
//     console.log("hello i'm arr");
// };

// //factory function 
// function PersonMaker(name,age){
//     const person={
//         name:name,
//         age: age,
//         talk(){
//             console.log(`Hi, my name is ${this.name}`);
//         },
//     };
//     return person;
// }
// let p1=PersonMaker("astha" , 21);
// let p2=PersonMaker("astha shukla" , 23);


//constructors-does not return anyhthig
// function Person(name,age){
//         this.name=name;
//         this.age=age;
        
// }
// Person.prototype.talk=function() {
//     console.log(`hi!,my name is ${this.name} `);
// }
// let p1=new Person("astha" , 21);
// let p2=new Person("astha shukla" , 23);

// //classes
// class Person{
//     constructor(name,age){
//         this.name=name;
//         this.age=age;
//     }
//     talk(){
//         console.log(`hi my name is ${this.name}`);
//     }
// }
// let p1=new Person("astha" , 21);
// let p2=new Person("astha shukla" , 23);

class Person {
    constructor(name, age){
        console.log("Person class constructor");

        this.name=name;
        this.age=age;
    }talk(){
        console.log(`hi im ${this.name}`);
    }
}
class Student extends Person{
    constructor(name,age,marks){
       super(name,age);//calling parent class
        this.marks=marks;
    }
   
}
let stu1=new Student ("astha" , 21,45);


class Teacher extends Person{
    constructor(name ,age,subject){
        console.log("student class constructor");
        super(name,age);//calling parent class

        this.subject=subject;
    }
    
}
let teac1=new Teacher ("astha" , 21,45);


