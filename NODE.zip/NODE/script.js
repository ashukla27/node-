import {sum,PI} from "./math.js";
import {generate} from "random-words";
console.log(generate());